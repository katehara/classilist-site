R Classilist Package
===============================

A connector extension for R and Classilist. Find installation, usage and other information [here](http://katehara.github.io/classilist-site).
