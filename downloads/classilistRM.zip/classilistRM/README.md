RapidMiner Classilist Extension
===============================

A connector extension for Rapidminer and Classilist. Find installation, usage and other information [here](http://katehara.github.io/classilist-site).
