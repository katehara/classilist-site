KNIME Classilist Extension
===============================

A connector extension for KNIME and Classilist. Find installation, usage and other information [here](http://katehara.github.io/classilist-site).
